from rest_framework import viewsets, permissions, status, filters
from rest_framework.decorators import action
from rest_framework.response import Response
from django_filters.rest_framework import DjangoFilterBackend
from jobsapp.models import Job, Applicant
from jobsapp.serializers import JobSerializer, ApplicantSerializer
from accounts.models import User

class JobViewSet(viewsets.ModelViewSet):
    queryset = Job.objects.all()
    serializer_class = JobSerializer
    permission_classes = [permissions.IsAuthenticated]
    filter_backends = [DjangoFilterBackend, filters.SearchFilter, filters.OrderingFilter]
    filterset_fields = ['type', 'category', 'location', 'filled']
    search_fields = ['title', 'description', 'company_name']
    ordering_fields = ['created_at', 'last_date', 'title']
    ordering = ['-created_at']

    def perform_create(self, serializer):
        serializer.save(user=self.request.user)

    @action(detail=True, methods=['post'])
    def apply(self, request, pk=None):
        job = self.get_object()
        if Applicant.objects.filter(job=job, user=request.user).exists():
            return Response(
                {'error': 'You have already applied for this job.'},
                status=status.HTTP_400_BAD_REQUEST
            )
        Applicant.objects.create(job=job, user=request.user)
        return Response({'status': 'Application submitted successfully'})

    @action(detail=False, methods=['get'])
    def my_jobs(self, request):
        queryset = self.get_queryset().filter(user=request.user)
        serializer = self.get_serializer(queryset, many=True)
        return Response(serializer.data)

class ApplicantViewSet(viewsets.ModelViewSet):
    queryset = Applicant.objects.all()
    serializer_class = ApplicantSerializer
    permission_classes = [permissions.IsAuthenticated]
    filter_backends = [DjangoFilterBackend, filters.SearchFilter, filters.OrderingFilter]
    filterset_fields = ['job__type', 'job__category', 'job__location']
    search_fields = ['user__first_name', 'user__last_name', 'user__email', 'job__title']
    ordering_fields = ['created_at']
    ordering = ['-created_at']

    def get_queryset(self):
        if self.request.user.is_employer:
            return Applicant.objects.filter(job__user=self.request.user)
        return Applicant.objects.filter(user=self.request.user)

    @action(detail=True, methods=['post'])
    def accept(self, request, pk=None):
        applicant = self.get_object()
        if not request.user.is_employer:
            return Response(
                {'error': 'Only employers can accept applications.'},
                status=status.HTTP_403_FORBIDDEN
            )
        applicant.job.filled = True
        applicant.job.save()
        return Response({'status': 'Application accepted successfully'}) 